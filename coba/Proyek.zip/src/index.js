
import 'regenerator-runtime';
import $ from 'jquery';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/style.css';
import main from "./main/main.js";


document.addEventListener("DOMContentLoaded", main);



